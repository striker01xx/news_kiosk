<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $url = "https://gnews.io/api/v4/search?q=economy+OR+finance+OR+stock+market+OR+inflation+OR+business&lang=en&max=5&apikey=92b57dabb4b148dacaafc52214785cb2";
  $json = file_get_contents($url);
  $data = json_decode($json, true);

  $unique = [];
  $seenTitles = [];

  foreach ($data['articles'] as $a) {
    $title = trim($a['title']);
    $cleanUrl = preg_replace('/^https?:\/\/(www\.)?/', '', $a['url']);
    $cleanUrl = preg_replace('/(\?.*)|\/$/', '', $cleanUrl);

    if (!in_array($title, $seenTitles)) {
      $seenTitles[] = $title;
      $a['url'] = "https://" . $cleanUrl;
      $unique[] = $a;
    }
  }

  $result = ['articles' => $unique];
  file_put_contents("data/economic_data.json", json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

  header('Content-Type: text/plain');
  echo 'Saved to data/economic_data.json';
} else {
  header('Content-Type: text/html');
  foreach (scandir('data') as $f) {
    if ($f !== '.' && $f !== '..') {
      echo "<a href='data/$f'>$f</a><br>";
    }
  }
}
?>
