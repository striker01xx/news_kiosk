<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: text/plain');
echo "⏳ Starting dadjoke fetch (without curl)...\n";

// Setup context with headers
$opts = [
    'http' => [
        'method' => "GET",
        'header' => "Accept: application/json\r\n" .
                    "User-Agent: DadJokeParser (https://lehre.bpm.in.tum.de/~go56sew)\r\n"
    ]
];

$context = stream_context_create($opts);
$url = 'https://icanhazdadjoke.com/';
$response = file_get_contents($url, false, $context);

if ($response === FALSE) {
    echo "❌ Failed to fetch joke\n";
    exit;
}

$data = json_decode($response, true);
$filename = "data/dadjoke.json";
$success = file_put_contents($filename, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

if ($success !== false) {
    echo "✅ Joke saved to $filename\n";
} else {
    echo "❌ Failed to write file: $filename\n";
}
?>
