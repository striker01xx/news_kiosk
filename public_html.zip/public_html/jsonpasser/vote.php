<?php
date_default_timezone_set('Europe/Berlin');

$category = $_GET['category'] ?? null;
$id = $_GET['id'] ?? null;

if (!$category || !$id) {
    http_response_code(400);
    echo json_encode(["error" => "Missing category or ID."]);
    exit;
}

$articleDataPath = __DIR__ . "/data/{$category}_data.json";
$votedDataPath = __DIR__ . "/data/voted_articles.json";

if (!file_exists($articleDataPath)) {
    http_response_code(404);
    echo json_encode(["error" => "Category data file not found."]);
    exit;
}

$articlesRaw = file_get_contents($articleDataPath);
$articlesJson = json_decode($articlesRaw, true);
$votedRaw = file_exists($votedDataPath) ? file_get_contents($votedDataPath) : '{"articles": []}';
$votedData = json_decode($votedRaw, true);

// Find the article
$matched = null;
foreach ($articlesJson['articles'] as $article) {
    if (($article['id'] ?? null) === $id) {
        $matched = $article;
        break;
    }
}

if (!$matched) {
    http_response_code(404);
    echo json_encode(["error" => "Article with given ID not found."]);
    exit;
}

$matched['category'] = $category;
$matched['votes'] = 1;
$matched['lastVoted'] = date('Y-m-d H:i:s');

// Overwrite if already voted, else push
$found = false;
foreach ($votedData['articles'] as &$votedArticle) {
    if (($votedArticle['id'] ?? null) === $id) {
        $votedArticle['votes'] += 1;
        $votedArticle['lastVoted'] = date('Y-m-d H:i:s');
        $found = true;
        break;
    }
}
unset($votedArticle);

if (!$found) {
    $votedData['articles'][] = $matched;
}

file_put_contents($votedDataPath, json_encode($votedData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

echo json_encode(["success" => true, "message" => "Vote registered."]);
